</main>
<footer class="site-footer">
    <div class="container footer-grid">
        <div>
            <h3>SmartBudget</h3>
            <p>A simple web-based personal finance and expense tracker.</p>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="about.php">About</a>
            <a href="expenses.php">Expenses</a>
            <a href="contact.php">Contact</a>
        </div>
        <div>
            <h4>Technology</h4>
            <p>HTML5 • CSS3 • JavaScript • PHP • MySQL</p>
        </div>
    </div>
    <div class="copyright">© 2026 SmartBudget. Individual Web Programming Project.</div>
</footer>
<script src="js/script.js"></script>
</body>
</html>
