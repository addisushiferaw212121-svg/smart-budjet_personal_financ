<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) : "SmartBudget"; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header class="site-header">
    <div class="container nav-wrap">
        <a class="logo" href="index.php">Smart<span>Budget</span></a>
        <button class="menu-toggle" onclick="toggleMenu()" aria-label="Toggle navigation">☰</button>
        <nav id="mainNav">
            <a href="index.php">Home</a>
            <a href="about.php">About</a>
            <a href="expenses.php">Expenses</a>
            <a href="contact.php">Contact</a>
            <?php if (isset($_SESSION["user_id"])): ?>
                <a href="dashboard.php">Dashboard</a>
                <a class="nav-button" href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a class="nav-button" href="register.php">Register</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<main>
