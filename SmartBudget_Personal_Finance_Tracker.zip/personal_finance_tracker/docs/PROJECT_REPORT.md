# SmartBudget Project Report

## 1. Project Title
**Personal Finance/Expense Tracker (Web-based)** — Project Title #20.

## 2. Introduction
SmartBudget is a web-based personal finance and expense tracking system developed for the CoSc3091 Web Programming individual assignment. The system allows registered users to maintain personal expense records through a simple responsive website.

The project demonstrates the use of HTML5 for semantic structure, CSS3 for responsive presentation, JavaScript for client-side validation and user-interface behavior, PHP for server-side processing, and MySQL for persistent data storage.

## 3. Main Features
1. Home landing page.
2. About page with student information and project purpose.
3. User registration.
4. User login and logout.
5. Session-based authentication.
6. Dashboard showing total expenses and number of records.
7. Add expense functionality.
8. View expense records.
9. Edit expense functionality.
10. Delete expense functionality.
11. Contact form stored in the database.
12. JavaScript and PHP validation.
13. Prepared SQL statements and password hashing.
14. Responsive desktop/mobile layout.

## 4. Pages
- `index.php` — Home
- `about.php` — About and student information
- `register.php` — Account creation
- `login.php` — Sign-in
- `dashboard.php` — User dashboard
- `add_expense.php` — Add expense
- `expenses.php` — Expense listing and deletion
- `edit_expense.php` — Edit expense
- `contact.php` — Working contact form
- `logout.php` — Session logout

## 5. Database Design / Table Structure

### users
| Field | Type | Key |
|---|---|---|
| id | INT | Primary Key, Auto Increment |
| name | VARCHAR(100) | Required |
| email | VARCHAR(120) | Unique |
| password | VARCHAR(255) | Required |
| created_at | TIMESTAMP | Default |

### expenses
| Field | Type | Key |
|---|---|---|
| id | INT | Primary Key, Auto Increment |
| user_id | INT | Foreign Key → users.id |
| title | VARCHAR(100) | Required |
| category | VARCHAR(50) | Required |
| amount | DECIMAL(10,2) | Required |
| expense_date | DATE | Required |
| description | VARCHAR(500) | Optional |
| created_at | TIMESTAMP | Default |

### messages
| Field | Type | Key |
|---|---|---|
| id | INT | Primary Key, Auto Increment |
| name | VARCHAR(100) | Required |
| email | VARCHAR(120) | Required |
| subject | VARCHAR(150) | Required |
| message | TEXT | Required |
| created_at | TIMESTAMP | Default |

### Relationship
One user can have many expenses. The `expenses.user_id` field references `users.id`. Deleting a user also deletes their expenses through `ON DELETE CASCADE`.

## 6. Security and Validation
The registration form validates required data and email format on the client and server. Passwords are stored using PHP's `password_hash()` and verified using `password_verify()`.

Database operations use mysqli prepared statements to reduce SQL injection risk. User-owned expense queries include the logged-in user's ID, preventing a user from managing another user's records. Displayed database values are escaped using `htmlspecialchars()` to reduce XSS risk.

## 7. Individual Contribution / Originality
This project is designed as an individual student project. The structure, database design, interface, authentication flow, expense CRUD operations, validation, and integration are organized for this specific assignment. The student should understand and be able to explain each part during demonstration or oral defense.

## 8. Screenshots
Add screenshots after running the project in XAMPP:
1. Home page
2. About page
3. Register page
4. Login page
5. Dashboard
6. Add Expense page
7. Expense list
8. Contact page

## 9. Conclusion
SmartBudget provides a manageable but complete example of a database-backed web application. It satisfies the major assignment requirements by combining multi-page HTML/CSS, JavaScript validation, PHP server-side processing, authentication, sessions, database persistence, and CRUD functionality.
