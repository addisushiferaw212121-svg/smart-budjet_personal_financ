<?php
$pageTitle = "Contact | SmartBudget";
include "includes/header.php";
require_once "config.php";

$message = "";
$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $subject = trim($_POST["subject"] ?? "");
    $body = trim($_POST["message"] ?? "");

    if ($name === "" || !filter_var($email, FILTER_VALIDATE_EMAIL) || $subject === "" || $body === "") {
        $error = "Please complete all fields with a valid email address.";
    } else {
        $stmt = $conn->prepare("INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $subject, $body);
        if ($stmt->execute()) {
            $message = "Thank you. Your message has been saved successfully.";
        } else {
            $error = "Could not save your message.";
        }
        $stmt->close();
    }
}
?>
<section class="page-banner">
<div class="container">
    <p class="eyebrow">GET IN TOUCH</p>
    <h1>Contact Us</h1>
    <p>Send a message using the working PHP contact form.</p>
</div>
</section>
<section class="section">
<div class="container contact-grid">
    <div class="card">
        <h2>Contact Information</h2>
        <p><strong>Project:</strong> SmartBudget</p>
        <p><strong>Department:</strong> Computer Science</p>
        <p><strong>Purpose:</strong> Web Programming Individual Assignment</p>
        <p>Your message is stored in the MySQL database after successful validation.</p>
    </div>
    <div class="card">
        <?php if ($error): ?><div class="alert error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
        <?php if ($message): ?><div class="alert success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
        <form method="POST" onsubmit="return validateContactForm()">
            <label>Name<input type="text" name="name" id="contactName" required></label>
            <label>Email<input type="email" name="email" id="contactEmail" required></label>
            <label>Subject<input type="text" name="subject" id="contactSubject" required></label>
            <label>Message<textarea name="message" id="contactMessage" rows="6" required></textarea></label>
            <button class="btn primary full" type="submit">Send Message</button>
        </form>
    </div>
</div>
</section>
<?php include "includes/footer.php"; ?>
