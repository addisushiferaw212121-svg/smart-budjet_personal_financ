function toggleMenu(){
    const nav=document.getElementById("mainNav");
    if(nav) nav.classList.toggle("open");
}

function validateRegisterForm(){
    const name=document.getElementById("name").value.trim();
    const email=document.getElementById("email").value.trim();
    const password=document.getElementById("password").value;
    if(name.length<2){alert("Please enter your full name.");return false;}
    if(!email.includes("@")){alert("Please enter a valid email.");return false;}
    if(password.length<6){alert("Password must be at least 6 characters.");return false;}
    return true;
}

function validateLoginForm(){
    const email=document.getElementById("loginEmail").value.trim();
    const password=document.getElementById("loginPassword").value;
    if(!email || !email.includes("@") || !password){alert("Please enter a valid email and password.");return false;}
    return true;
}

function validateExpenseForm(){
    const title=document.getElementById("expenseTitle").value.trim();
    const amount=parseFloat(document.getElementById("amount").value);
    const category=document.getElementById("category").value;
    const date=document.getElementById("expenseDate").value;
    if(!title || !category || !date || isNaN(amount) || amount<=0){
        alert("Please complete all required expense fields.");
        return false;
    }
    return true;
}

function validateContactForm(){
    const name=document.getElementById("contactName").value.trim();
    const email=document.getElementById("contactEmail").value.trim();
    const subject=document.getElementById("contactSubject").value.trim();
    const message=document.getElementById("contactMessage").value.trim();
    if(!name || !email.includes("@") || !subject || !message){
        alert("Please complete the contact form correctly.");
        return false;
    }
    return true;
}
