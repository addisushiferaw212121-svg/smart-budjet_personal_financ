# SmartBudget — Personal Finance/Expense Tracker

## Course
CoSc3091 – Web Programming  
Individual Assignment I – Full Website Development Project

## Project Title
Project #20: Personal Finance/Expense Tracker (Web-based)

## Student
- Full Name: BESUFEKAD DENEKE
- ID Number: ____________________
- Department: Computer Science

## Features
- Home, About, Expenses, Contact, Register, Login and Dashboard pages
- User registration with password_hash()
- Login with sessions and password_verify()
- Logout
- Add, view, edit and delete personal expenses
- Total expense and record count
- Working PHP contact form stored in MySQL
- JavaScript client-side validation
- Server-side validation
- Prepared statements using mysqli
- Responsive HTML/CSS layout
- User-specific expense records

## Technologies
HTML5, CSS3, JavaScript, PHP, MySQL/MariaDB.

## Local Setup with XAMPP
1. Install XAMPP.
2. Start Apache and MySQL.
3. Copy the `personal_finance_tracker` folder into `C:/xampp/htdocs/`.
4. Open phpMyAdmin at `http://localhost/phpmyadmin`.
5. Import `database/database.sql`.
6. Check `config.php`. The default XAMPP MySQL settings are:
   - Host: localhost
   - Username: root
   - Password: empty
   - Database: personal_finance_tracker
7. Open `http://localhost/personal_finance_tracker/`.
8. Create a user using Register, then log in.

## Test Credentials
Create the test account through the Register page. Do not store plain-text passwords in the database.

## Security Notes
Passwords are hashed with `password_hash()`. SQL statements use prepared statements. Output shown in HTML is escaped with `htmlspecialchars()` to reduce XSS risk. Sessions are used for authentication and users can only manage their own expenses.

## GitHub
Create a public repository and use multiple meaningful commits, for example:
1. Initial project structure
2. Added HTML/CSS pages
3. Added registration and login
4. Added database and expense CRUD
5. Added contact form and validation
6. Added documentation and final testing

## Deployment
If PHP/MySQL hosting is available, upload the project and import the SQL database. Otherwise, include these XAMPP instructions for local evaluation.
