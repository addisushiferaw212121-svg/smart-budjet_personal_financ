<?php
$pageTitle = "Add Expense | SmartBudget";
include "includes/header.php";
require_once "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST["title"] ?? "");
    $category = trim($_POST["category"] ?? "");
    $amount = (float)($_POST["amount"] ?? 0);
    $date = $_POST["expense_date"] ?? "";
    $description = trim($_POST["description"] ?? "");

    if ($title === "" || $category === "" || $amount <= 0 || $date === "") {
        $error = "Please complete all required fields and enter an amount greater than zero.";
    } else {
        $stmt = $conn->prepare("INSERT INTO expenses (user_id, title, category, amount, expense_date, description) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issdss", $_SESSION["user_id"], $title, $category, $amount, $date, $description);
        if ($stmt->execute()) {
            header("Location: expenses.php?added=1");
            exit;
        }
        $error = "Could not save the expense.";
        $stmt->close();
    }
}
?>
<section class="auth-section">
<div class="auth-card wide">
    <p class="eyebrow">EXPENSE MANAGEMENT</p>
    <h1>Add Expense</h1>
    <?php if ($error): ?><div class="alert error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="POST" onsubmit="return validateExpenseForm()">
        <label>Expense Title<input type="text" name="title" id="expenseTitle" maxlength="100" required></label>
        <label>Category
            <select name="category" id="category" required>
                <option value="">Choose category</option>
                <option>Food</option><option>Transport</option><option>Education</option>
                <option>Rent</option><option>Shopping</option><option>Health</option>
                <option>Entertainment</option><option>Other</option>
            </select>
        </label>
        <label>Amount<input type="number" name="amount" id="amount" min="0.01" step="0.01" required></label>
        <label>Date<input type="date" name="expense_date" id="expenseDate" required></label>
        <label>Description<textarea name="description" rows="4" maxlength="500" placeholder="Optional description"></textarea></label>
        <button class="btn primary full" type="submit">Save Expense</button>
    </form>
</div>
</section>
<?php include "includes/footer.php"; ?>
