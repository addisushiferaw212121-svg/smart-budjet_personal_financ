<?php
$pageTitle = "SmartBudget | Home";
include "includes/header.php";
?>
<section class="hero">
    <div class="container hero-content">
        <div>
            <p class="eyebrow">PERSONAL FINANCE TRACKER</p>
            <h1>Take control of your money, one expense at a time.</h1>
            <p class="hero-text">SmartBudget helps you record, organize, and understand your daily spending with a simple and responsive website.</p>
            <div class="hero-actions">
                <a class="btn primary" href="<?php echo isset($_SESSION['user_id']) ? 'dashboard.php' : 'register.php'; ?>">Get Started</a>
                <a class="btn secondary" href="about.php">Learn More</a>
            </div>
        </div>
        <div class="hero-card">
            <div class="mini-card">
                <span>Simple</span><strong>Easy expense entry</strong>
            </div>
            <div class="mini-card">
                <span>Secure</span><strong>Protected user accounts</strong>
            </div>
            <div class="mini-card">
                <span>Useful</span><strong>Track spending totals</strong>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-heading">
            <p class="eyebrow">FEATURES</p>
            <h2>Everything you need to track expenses</h2>
        </div>
        <div class="feature-grid">
            <article class="feature-card"><div class="icon">＋</div><h3>Add Expenses</h3><p>Record an expense with amount, category, date, and description.</p></article>
            <article class="feature-card"><div class="icon">✓</div><h3>Manage Records</h3><p>View, edit, and delete your own expense records.</p></article>
            <article class="feature-card"><div class="icon">▤</div><h3>See Totals</h3><p>Get a quick view of your total spending from the database.</p></article>
            <article class="feature-card"><div class="icon">⌕</div><h3>Stay Organized</h3><p>Use categories and dates to understand where your money goes.</p></article>
        </div>
    </div>
</section>
<?php include "includes/footer.php"; ?>
