<?php
$pageTitle = "Expenses | SmartBudget";
include "includes/header.php";
require_once "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$userId = (int)$_SESSION["user_id"];
if (isset($_GET["delete"])) {
    $id = (int)$_GET["delete"];
    $stmt = $conn->prepare("DELETE FROM expenses WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $id, $userId);
    $stmt->execute();
    $stmt->close();
    header("Location: expenses.php?deleted=1");
    exit;
}

$stmt = $conn->prepare("SELECT id, title, category, amount, expense_date, description FROM expenses WHERE user_id = ? ORDER BY expense_date DESC, id DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
?>
<section class="page-banner">
<div class="container">
    <p class="eyebrow">YOUR RECORDS</p>
    <h1>Expenses</h1>
    <p>View and manage the expenses stored in your account.</p>
</div>
</section>
<section class="section">
<div class="container">
    <?php if (isset($_GET["added"])): ?><div class="alert success">Expense added successfully.</div><?php endif; ?>
    <?php if (isset($_GET["deleted"])): ?><div class="alert success">Expense deleted successfully.</div><?php endif; ?>
    <div class="dashboard-actions"><a class="btn primary" href="add_expense.php">+ Add Expense</a></div>
    <div class="card">
    <div class="table-wrap">
    <table>
        <thead><tr><th>Title</th><th>Category</th><th>Amount</th><th>Date</th><th>Actions</th></tr></thead>
        <tbody>
        <?php if ($result->num_rows === 0): ?>
            <tr><td colspan="5" class="empty">No expenses found. Add your first expense.</td></tr>
        <?php else: while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row["title"]); ?></td>
                <td><?php echo htmlspecialchars($row["category"]); ?></td>
                <td>$<?php echo number_format((float)$row["amount"], 2); ?></td>
                <td><?php echo htmlspecialchars($row["expense_date"]); ?></td>
                <td>
                    <a class="small-btn" href="edit_expense.php?id=<?php echo $row["id"]; ?>">Edit</a>
                    <a class="small-btn danger-link" onclick="return confirm('Delete this expense?')" href="expenses.php?delete=<?php echo $row["id"]; ?>">Delete</a>
                </td>
            </tr>
        <?php endwhile; endif; ?>
        </tbody>
    </table>
    </div>
    </div>
</div>
</section>
<?php
$stmt->close();
include "includes/footer.php";
?>
