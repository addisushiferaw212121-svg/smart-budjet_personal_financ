<?php
$pageTitle = "About | SmartBudget";
include "includes/header.php";
?>
<section class="page-banner">
    <div class="container">
        <p class="eyebrow">ABOUT THE PROJECT</p>
        <h1>About SmartBudget</h1>
        <p>A practical web programming project built with HTML, CSS, JavaScript, PHP and MySQL.</p>
    </div>
</section>

<section class="section">
    <div class="container about-grid">
        <article class="card">
            <h2>Student Information</h2>
            <p><strong>Full Name:</strong> BESUFEKAD DENEKE</p>
            <p><strong>ID Number:</strong> ____________________</p>
            <p><strong>Department:</strong> Computer Science</p>
            <p>I am a Computer Science student interested in web development and practical software projects. I chose SmartBudget because an expense tracker is a useful system that can demonstrate forms, authentication, database operations, validation, and responsive web design in one manageable project.</p>
        </article>
        <article class="card">
            <h2>System Purpose</h2>
            <p>SmartBudget is a web-based personal finance/expense tracker. Registered users can securely sign in and manage their own expense records.</p>
            <ul class="check-list">
                <li>User registration and secure password hashing</li>
                <li>Login, sessions and logout</li>
                <li>Add, view, edit and delete expenses</li>
                <li>Database-backed contact messages</li>
                <li>Client-side and server-side validation</li>
                <li>Responsive layout for desktop and mobile</li>
            </ul>
        </article>
    </div>
</section>
<?php include "includes/footer.php"; ?>
