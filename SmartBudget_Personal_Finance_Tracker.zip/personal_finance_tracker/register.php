<?php
$pageTitle = "Register | SmartBudget";
include "includes/header.php";
require_once "config.php";

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($name === "" || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) {
        $error = "Please provide a name, valid email, and password of at least 6 characters.";
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = "This email is already registered.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $email, $hash);
            if ($stmt->execute()) {
                $message = "Registration successful. You can now log in.";
            } else {
                $error = "Registration failed. Please try again.";
            }
            $stmt->close();
        }
        $check->close();
    }
}
?>
<section class="auth-section">
<div class="auth-card">
    <p class="eyebrow">CREATE ACCOUNT</p>
    <h1>Register</h1>
    <?php if ($error): ?><div class="alert error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <?php if ($message): ?><div class="alert success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
    <form method="POST" onsubmit="return validateRegisterForm()">
        <label>Full Name<input type="text" id="name" name="name" required></label>
        <label>Email<input type="email" id="email" name="email" required></label>
        <label>Password<input type="password" id="password" name="password" minlength="6" required></label>
        <button class="btn primary full" type="submit">Create Account</button>
    </form>
    <p class="form-note">Already have an account? <a href="login.php">Login here</a>.</p>
</div>
</section>
<?php include "includes/footer.php"; ?>
