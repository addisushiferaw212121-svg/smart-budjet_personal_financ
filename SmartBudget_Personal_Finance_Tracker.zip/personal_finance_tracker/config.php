<?php
// Database configuration
$host = "localhost";
$dbname = "personal_finance_tracker";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Database connection failed. Please check your XAMPP/MySQL settings.");
}

$conn->set_charset("utf8mb4");
?>
