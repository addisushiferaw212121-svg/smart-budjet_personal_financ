<?php
$pageTitle = "Edit Expense | SmartBudget";
include "includes/header.php";
require_once "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$id = (int)($_GET["id"] ?? 0);
$userId = (int)$_SESSION["user_id"];
$error = "";

$get = $conn->prepare("SELECT title, category, amount, expense_date, description FROM expenses WHERE id = ? AND user_id = ?");
$get->bind_param("ii", $id, $userId);
$get->execute();
$expense = $get->get_result()->fetch_assoc();
$get->close();

if (!$expense) {
    echo '<section class="section"><div class="container"><div class="alert error">Expense not found.</div></div></section>';
    include "includes/footer.php";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST["title"] ?? "");
    $category = trim($_POST["category"] ?? "");
    $amount = (float)($_POST["amount"] ?? 0);
    $date = $_POST["expense_date"] ?? "";
    $description = trim($_POST["description"] ?? "");

    if ($title === "" || $category === "" || $amount <= 0 || $date === "") {
        $error = "Please complete all required fields.";
    } else {
        $stmt = $conn->prepare("UPDATE expenses SET title=?, category=?, amount=?, expense_date=?, description=? WHERE id=? AND user_id=?");
        $stmt->bind_param("ssdssii", $title, $category, $amount, $date, $description, $id, $userId);
        if ($stmt->execute()) {
            header("Location: expenses.php");
            exit;
        }
        $error = "Could not update the expense.";
        $stmt->close();
    }
}
?>
<section class="auth-section">
<div class="auth-card wide">
    <p class="eyebrow">EXPENSE MANAGEMENT</p>
    <h1>Edit Expense</h1>
    <?php if ($error): ?><div class="alert error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="POST" onsubmit="return validateExpenseForm()">
        <label>Expense Title<input type="text" name="title" id="expenseTitle" value="<?php echo htmlspecialchars($expense["title"]); ?>" required></label>
        <label>Category
            <select name="category" id="category" required>
                <?php foreach (["Food","Transport","Education","Rent","Shopping","Health","Entertainment","Other"] as $cat): ?>
                    <option <?php echo $expense["category"] === $cat ? "selected" : ""; ?>><?php echo $cat; ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Amount<input type="number" name="amount" id="amount" min="0.01" step="0.01" value="<?php echo htmlspecialchars($expense["amount"]); ?>" required></label>
        <label>Date<input type="date" name="expense_date" id="expenseDate" value="<?php echo htmlspecialchars($expense["expense_date"]); ?>" required></label>
        <label>Description<textarea name="description" rows="4"><?php echo htmlspecialchars($expense["description"]); ?></textarea></label>
        <button class="btn primary full" type="submit">Update Expense</button>
    </form>
</div>
</section>
<?php include "includes/footer.php"; ?>
