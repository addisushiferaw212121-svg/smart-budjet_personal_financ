<?php
$pageTitle = "Login | SmartBudget";
include "includes/header.php";
require_once "config.php";

$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === "") {
        $error = "Please enter a valid email and password.";
    } else {
        $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user && password_verify($password, $user["password"])) {
            session_regenerate_id(true);
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["user_name"] = $user["name"];
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Incorrect email or password.";
        }
        $stmt->close();
    }
}
?>
<section class="auth-section">
<div class="auth-card">
    <p class="eyebrow">WELCOME BACK</p>
    <h1>Login</h1>
    <?php if ($error): ?><div class="alert error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="POST" onsubmit="return validateLoginForm()">
        <label>Email<input type="email" id="loginEmail" name="email" required></label>
        <label>Password<input type="password" id="loginPassword" name="password" required></label>
        <button class="btn primary full" type="submit">Sign In</button>
    </form>
    <p class="form-note">New user? <a href="register.php">Create an account</a>.</p>
</div>
</section>
<?php include "includes/footer.php"; ?>
