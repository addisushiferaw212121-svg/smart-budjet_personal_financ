<?php
$pageTitle = "Dashboard | SmartBudget";
include "includes/header.php";
require_once "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$userId = (int)$_SESSION["user_id"];
$total = 0;
$count = 0;
$stmt = $conn->prepare("SELECT COALESCE(SUM(amount),0) AS total, COUNT(*) AS count FROM expenses WHERE user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();
$total = $data["total"];
$count = $data["count"];
$stmt->close();

$recent = $conn->prepare("SELECT title, category, amount, expense_date FROM expenses WHERE user_id = ? ORDER BY expense_date DESC, id DESC LIMIT 5");
$recent->bind_param("i", $userId);
$recent->execute();
$recentRows = $recent->get_result();
?>
<section class="page-banner">
    <div class="container">
        <p class="eyebrow">PERSONAL DASHBOARD</p>
        <h1>Hello, <?php echo htmlspecialchars($_SESSION["user_name"]); ?> 👋</h1>
        <p>Manage your personal expense records from one place.</p>
    </div>
</section>
<section class="section">
<div class="container">
    <div class="stats-grid">
        <div class="stat-card"><span>Total Expenses</span><strong>$<?php echo number_format((float)$total, 2); ?></strong></div>
        <div class="stat-card"><span>Records</span><strong><?php echo (int)$count; ?></strong></div>
        <div class="stat-card"><span>Account</span><strong>Active</strong></div>
    </div>
    <div class="dashboard-actions">
        <a class="btn primary" href="add_expense.php">+ Add Expense</a>
        <a class="btn secondary" href="expenses.php">View All Expenses</a>
    </div>
    <div class="card">
        <h2>Recent Expenses</h2>
        <div class="table-wrap">
        <table>
            <thead><tr><th>Title</th><th>Category</th><th>Amount</th><th>Date</th></tr></thead>
            <tbody>
            <?php if ($recentRows->num_rows === 0): ?>
                <tr><td colspan="4" class="empty">No expenses recorded yet.</td></tr>
            <?php else: while ($row = $recentRows->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row["title"]); ?></td>
                    <td><?php echo htmlspecialchars($row["category"]); ?></td>
                    <td>$<?php echo number_format((float)$row["amount"], 2); ?></td>
                    <td><?php echo htmlspecialchars($row["expense_date"]); ?></td>
                </tr>
            <?php endwhile; endif; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
</section>
<?php
$recent->close();
include "includes/footer.php";
?>
